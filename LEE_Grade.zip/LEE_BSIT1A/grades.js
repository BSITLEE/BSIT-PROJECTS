const midtermInput = document.getElementById('midterm');
const fExamInput = document.getElementById('fExam');
const fGradeOutput = document.getElementById('fGrade');
const remarksOutput = document.getElementById('remarks');
const computeButton = document.getElementById('compB');
const resetButton = document.getElementById('resetB');

const gradeRemarks = {
    100: 1.0,
    98: 1.1,
    95: 1.2,
    93: 1.3,
    90: 1.5,
    89: 1.6,
    87: 1.8,
    86: 1.9,
    85: 2.0,
    84: 2.1,
    83: 2.2,
    82: 2.3,
    81: 2.4,
    80: 2.5,
    79: 2.6,
    78: 2.7,
    77: 2.8,
    76: 2.9,
    75: 3.0,
    70: 5.0
};

computeButton.onclick = function() {
    const midtermGrade = parseFloat(midtermInput.value);
    const fExamGrade = parseFloat(fExamInput.value);

    if (isNaN(midtermGrade) || isNaN(fExamGrade)) {
        fGradeOutput.textContent = "Invalid ( ,,⩌'︿'⩌,,)";
        remarksOutput.textContent = "*";
        return;
    }

    const fGrade = (midtermGrade + fExamGrade) / 2;
    fGradeOutput.textContent = fGrade.toFixed(2);

    let remark = "Failed ( • ᴖ • ｡)";

    if (fGrade >= 100) {
        remark = gradeRemarks[100];
    } else if (fGrade >= 98) {
        remark = gradeRemarks[98];
    } else if (fGrade >= 95) {
        remark = gradeRemarks[95];
    } else if (fGrade >= 93) {
        remark = gradeRemarks[93];
    } else if (fGrade >= 90) {
        remark = gradeRemarks[90];
    } else if (fGrade >= 89) {
        remark = gradeRemarks[89];
    } else if (fGrade >= 87) {
        remark = gradeRemarks[87];
    } else if (fGrade >= 86) {
        remark = gradeRemarks[86];
    } else if (fGrade >= 85) {
        remark = gradeRemarks[85];
    } else if (fGrade >= 84) {
        remark = gradeRemarks[84];
    } else if (fGrade >= 83) {
        remark = gradeRemarks[83];
    } else if (fGrade >= 82) {
        remark = gradeRemarks[82];
    } else if (fGrade >= 81) {
        remark = gradeRemarks[81];
    } else if (fGrade >= 80) {
        remark = gradeRemarks[80];
    } else if (fGrade >= 79) {
        remark = gradeRemarks[79];
    } else if (fGrade >= 78) {
        remark = gradeRemarks[78];
    } else if (fGrade >= 77) {
        remark = gradeRemarks[77];
    } else if (fGrade >= 76) {
        remark = gradeRemarks[76];
    } else if (fGrade >= 75) {
        remark = gradeRemarks[75];
    } else if (fGrade >= 70) {
        remark = gradeRemarks[70];
    }
    
    remarksOutput.textContent = remark;
};

resetButton.onclick = function() {
    midtermInput.value = "";
    fExamInput.value = "";
    fGradeOutput.textContent = "*";
    remarksOutput.textContent = "*";
};