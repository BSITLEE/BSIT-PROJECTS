let lights = document.querySelectorAll(".circle");
let light = 0;

setInterval(() => {
    changeLight();
}, 1000);

function changeLight() {
    lights[light].classList.remove(lights[light].getAttribute("color"));

    light++;

    if (light > 2) {
        light = 0;
    }
    const selectLight = lights[light];
    selectLight.classList.add(selectLight.getAttribute("color"));
}
